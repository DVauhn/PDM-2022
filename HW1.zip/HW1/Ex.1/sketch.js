function setup() {
  createCanvas(750, 400);
}

function draw() {
  background(0, 255, 0);

  fill(255, 255, 255)

  circle(200, 200, 300)

  rect(400, 50, 300, 300)

}