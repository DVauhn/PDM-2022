function setup() {
  createCanvas(750, 400);
}

function draw() {
  stroke(0)
  strokeWeight(0)

  background(750,400)

  fill(255, 0, 0, 127) 
  circle(300, 100, 200)

  fill(0, 0, 255, 127) 
  circle(225, 225, 200)

  fill(0, 255, 0, 127)
  circle(375, 225, 200)


}